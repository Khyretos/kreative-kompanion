pub fn parse_git(output: &str) -> Option<(String, String)> {
    let lines: Vec<&str> = output.lines().collect();
    let exit_idx = lines.iter().rposition(|l| l.trim_start().starts_with("exit:"));
    
    if let Some(idx) = exit_idx {
        let exit_line = lines[idx].trim();
        let num_part = exit_line.strip_prefix("exit:").map(|s| s.trim());
        if num_part != Some("0") {
            return None;
        }
    } else {
        return None;
    }
    
    let body_lines: Vec<String> = lines.iter()
        .take(if let Some(idx) = exit_idx { idx } else { lines.len() })
        .filter_map(|l| {
            let trimmed = l.trim();
            if trimmed.is_empty() {
                None
            } else {
                Some(trimmed.to_string())
            }
        })
        .collect();
    
    if body_lines.len() < 2 {
        return None;
    }
    
    let remote = body_lines[0].clone();
    let branch = body_lines[1].clone();
    
    let clean_remote = if let Some(pos) = remote.find("://") {
        let after_proto = &remote[pos + 3..];
        if let Some(at_pos) = after_proto.find('@') {
            let mut end_at = if let Some(slash) = slash_pos {
                pos + 3 + at_pos + 1 + slash
            } else {
                pos + 3 + at_pos + 1
            };
            // Ensure we don't slice past the end of `remote`
            let len = remote.len();
            if end_at > len {
                end_at = len;
            }
            remote[..end_at].to_string() + &after_proto[at_pos + 1..]
        } else {
            remote.clone()
        }
    } else {
        remote.clone()
    };
    
    Some((clean_remote, branch))
