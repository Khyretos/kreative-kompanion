function accessCount(o: ProjectOverview | undefined): number {
  if (!o || o.access === null) return 0;
  let count = 0;
  for (const _ of o.access.grants) count++;
  for (const _ of o.access.knowledge) count++;
  for (const _ of o.access.mcp) count++;
  if (o.access.accessCount > 0) count += o.access.accessCount;
  return count;
}

function access(v: OverviewView): SafeHtml {
  if (!v.o) return html`<p class="muted">Loading…</p>`;
  if (v.o.access === null) {
    const err = v.o.errors.access ?? "";
    return html`<p class="muted">Could not read this part: ${err}</p>`;
  }
  const a = v.o.access;
  const items: Array<SafeHtml> = [];

  for (const g of a.grants) {
    items.push(html`<li><span>${rightsLabel(g.rights)}</span> · <code>${g.target}</code>${g.expires ? ` · until ${until(g.expires)}` : ""}</li>`);
  }
  for (const k of a.knowledge) {
    items.push(html`<li><span>Knowledge</span> · ${k.name}</li>`);
  }
  for (const m of a.mcp) {
    items.push(html`<li><span>MCP</span> · ${m.server}${m.tool !== "*" ? ` / ${m.tool}` : ""} · until ${until(m.expires)}</li>`);
  }
  if (a.assets > 0) {
    items.push(html`<li>${String(a.assets)} library assets attached</li>`);
  }

  if (items.length === 0) {
    return html`<p class="muted">Nothing granted yet. Computer grants are set on the Access tab.</p>`;
  }

  return html`<ul class="ov-access">${items}</ul>`;
}

function build(v: OverviewView): SafeHtml {
  if (!v.o) {
    return html`<p class="muted">Loading…</p>`;
  }
  const access = v.o.access;
  if (access === null) {
    return html`<p class="muted">Could not read this part: ${v.o.errors.access ?? ""}</p>`;
  }
  const cmds = access.commands;
  if (cmds.length === 0) {
    return html`<p class="muted">No build, test or run commands yet. Add them in Settings.</p>`;
  }

  const items = cmds.map((c) => {
    const label = c.kind === "build" ? "Build" : c.kind === "test" ? "Test" : c.kind === "run" ? "Run" : "Deploy";
    return html`<li>
      <span class="ov-kind">${label}</span>
      <code>${c.command}</code>
      ${c.last ? html`<span class="dev-result ${c.last.ok ? "ok" : "bad"}">${c.last.ok ? "Passed" : "Failed"} · ${relTime(c.last.at)}</span>` : ""}
      ${c.fromHere ? "" : html`<span class="muted small">never run from here</span>`}
    </li>`;
  });

  return html`<ul class="ov-cmds">${items}</ul>`;
}

function activity(v: OverviewView): SafeHtml {
  if (!v.o) {
    return html`<p class="muted">Loading…</p>`;
  }
  if (v.o.activity === null) {
    const err = v.o.errors.activity ?? "";
    return html`<p class="muted">Could not read this part: ${err}</p>`;
  }
  if (v.o.activity.length === 0) {
    return html`<p class="muted">Nothing yet.</p>`;
  }
  const shown = v.o.activity.slice(0, v.activityAll ? 10 : 5);
  const moreBtn = !v.activityAll && shown.length > 5
    ? html`<button class="btn small" type="button" data-action="overview-activity-more" data-id="${v.project.id}">More</button>`
    : html``;

  return html`
    <ul class="ov-act">
      ${shown.map((a) => html`
        <li>
          <span class="ov-what">${a.what}</span>
          <span class="ov-when muted">${relTime(a.at)}${a.who ? ` · ${a.who}` : ""}</span>
        </li>
      `)}
    </ul>
    ${moreBtn}
  `;
}

function ai(v: OverviewView): SafeHtml {
  if (!v.o) {
    return html`<p class="muted">Loading…</p>`;
  }
  const aiData = v.o.ai;
  if (aiData === null) {
    const err = v.o.errors.ai ?? "";
    return html`<p class="muted">Could not read this part: ${err}</p>`;
  }
  if (aiData.length === 0) {
    return html`<p class="muted">No model runs in the last 30 days.</p>`;
  }

  const items = aiData.map((m) => {
    const runsText = m.runs === 1 ? "1 run" : `${m.runs} runs`;
    const tokens =
      m.tokens >= 1000
        ? `${(m.tokens / 1000).toFixed(m.tokens >= 100000 ? 0 : 1)}k`
        : String(m.tokens);
    return html`<li><strong>${m.model}</strong> · ${runsText} · ${tokens} tokens · ${String(m.minutes)} min</li>`;
  });

  return html`<ul class="ov-ai">${items}</ul>`;
}

function editForm(v: OverviewView): SafeHtml {
  const name = v.o?.name ?? v.project.name;
  const description = v.o?.description ?? v.project.description;
  const about = v.o?.about ?? "";
  const links = v.o?.links ?? [];
  const synced = (v.o?.kind ?? v.project.kind) === "windshift";
  const linksText = (l: ProjectLink[]) => l.map((x) => `${x.label} ${x.url}`).join("\n");

  return html`<form class="overview-edit" data-id="${v.project.id}">
    <label>Name <input name="name" value="${name}" maxlength="80" required autocomplete="off" ${synced ? "disabled" : ""}></label>
    <label>Description <input name="description" value="${description}" maxlength="200" placeholder="One line: what it is" autocomplete="off" ${synced ? "disabled" : ""}></label>
    ${synced ? html`<p class="muted small">Name and description come from Windshift.</p>` : ""}
    <label>About <textarea name="about" rows="8" placeholder="Markdown: what it is for, who it is for, how it works">${about}</textarea></label>
    <div class="ov-preview-row"><button class="btn small" type="button" data-action="overview-preview" data-id="${v.project.id}">${v.preview ? "Hide preview" : "Preview"}</button></div>
    ${v.preview ? html`<div class="ov-preview md" data-md-preview></div>` : ""}
    <label>Links <textarea name="links" rows="3" placeholder="One per line: Label https://address">${linksText(links)}</textarea></label>
    <div class="ov-edit-actions"><button class="btn small primary" type="submit">Save</button><button class="btn small" type="button" data-action="overview-cancel">Cancel</button></div>
  </form>`;
}

/** The whole Overview; `settings` is the project's settings panel, shown inside the Settings section. */
export function renderOverview(v: OverviewView, settings: SafeHtml): SafeHtml {
  if (!v.o) return html`<section class="overview" data-id="${v.project.id}" aria-label="Project overview">Loading...</section>`;
  const o = v.o;
  const accessCountVal = accessCount(o);
  const whereOk = !o.errors?.where;
  const accessOk = !o.errors?.access;
  const progressOk = !o.errors?.progress;
  const activityOk = !o.errors?.activity;
  const aiOk = !o.errors?.ai;

  const headerVal = header(v);
  const tilesVal = tiles(v);
  const aboutVal = about(v);
  const whereVal = where(v);
  const accessVal = access(v);
  const buildVal = build(v);
  const activityVal = activity(v);
  const aiVal = ai(v);

  return html`
    <section class="overview" data-id="${v.project.id}" aria-label="Project overview">
      ${headerVal}
      ${v.editing ? editForm(v) : html`${tilesVal}${aboutVal}`}
      ${section("where", "Where it lives", undefined, v.open("where"), whereVal)}
      ${section("access", "Access", accessCountVal, v.open("access"), accessVal)}
      ${section("build", "Build and test", undefined, v.open("build"), buildVal)}
      ${section("activity", "Recent activity", undefined, v.open("activity"), activityVal)}
      ${section("ai", "AI use", undefined, v.open("ai"), aiVal)}
      ${section("settings", "Settings", undefined, v.open("settings"), settings)}
    </section>
  `;
}

