function where(v: OverviewView): SafeHtml {
  if (!v.o) {
    return html`<p class="muted">Loading…</p>`;
  }
  const w = v.o.where;
  if (w === null) {
    const err = v.o.errors.where ?? "";
    return html`<p class="muted">Could not read this part: ${err}</p>`;
  }

  // computer
  if (w.machine) {
    const m = w.machine;
    return html`
      <p class="ov-machine">
        <span class="dot ${m.online ? "ok" : "off"}" aria-hidden="true"></span>
        ${m.name}${m.os ? ` · ${m.os}` : ""}${m.online ? "" : " · offline"}
      </p>
    `;
  } else {
    return html`<p class="muted">No computer yet. Pick one in Settings.</p>`;
  }
}
