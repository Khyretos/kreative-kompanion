pub async fn settings(
    State(s): State<AppState>,
    Extension(u): Extension<User>,
    Path(id): Path<String>,
    Json(b): Json<SettingsBody>,
) -> ApiResult<StatusCode> {
    owned(&s, &id, &u).await?;

    // PROJ-OVERVIEW: check kind before allowing name/description changes
    let kind: String = sqlx::query_scalar::<_, String>("SELECT kind FROM projects WHERE id = ?")
        .bind(&id)
        .fetch_one(&s.db)
        .await?;
    if kind == "windshift" {
        return Err(ApiError::BadRequest(
            "This project is synced with Windshift: change its name and description there.".into(),
        ));
    }

    // PROJ-OVERVIEW: validate name
    if let Some(n) = &b.name {
        let n = n.trim();
        if n.chars().count() < 1 || n.chars().count() > 80 {
            return Err(ApiError::BadRequest("A name has 1 to 80 characters.".into()));
        }
        sqlx::query("UPDATE projects SET name = ? WHERE id = ?")
            .bind(n)
            .bind(&id)
            .execute(&s.db)
            .await?;
    }

    // PROJ-OVERVIEW: validate description
    if let Some(d) = &b.description {
        let d = d.trim();
        if d.contains('\n') || d.contains('\r') || d.len() > 200 {
            return Err(ApiError::BadRequest("The description is one line of at most 200 characters.".into()));
        }
        sqlx::query("UPDATE projects SET description = ? WHERE id = ?")
            .bind(d)
            .bind(&id)
            .execute(&s.db)
            .await?;
    }

    // PROJ-OVERVIEW: validate about
    if let Some(a) = &b.about {
        let a = a.trim();
        if a.len() > crate::overview::ABOUT_MAX {
            return Err(ApiError::BadRequest("The about text is at most 20,000 bytes.".into()));
        }
        sqlx::query("UPDATE projects SET about = ? WHERE id = ?")
            .bind(a)
            .bind(&id)
            .execute(&s.db)
            .await?;
    }

    // PROJ-OVERVIEW: validate links
    if let Some(l) = &b.links {
        let links_json = clean_links(l)?;
        sqlx::query("UPDATE projects SET links = ? WHERE id = ?")
            .bind(links_json)
            .bind(&id)
            .execute(&s.db)
            .await?;
    }

