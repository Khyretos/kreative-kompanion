    <div class="task-groups">
      ${scope === "project" ? html`
        ${renderOverview({
          project: project!,
          o: s.overviews[project!.id],
          editing: s.overviewEditing === project!.id,
          more: s.overviewMore.has(project!.id),
          activityAll: s.overviewActivityAll.has(project!.id),
          preview: s.overviewPreview !== undefined,
          open: (sec) => s.overviewOpen[`${project!.id}:${sec}`] ?? openByDefault(sec, s.overviews[project!.id]),
        })}
        ${renderProjectPanel(project!, {
          machines: s.machines.filter((m) => m.id !== "server").map((m) => ({ id: m.id, name: m.name })),
          assets: s.projectAssets[project!.id],
          dev: s.devSettings[project!.id],
          pick: s.assetPick.project === project!.id ? s.assetPick : { q: "", items: [], busy: false },
          thumb,
        })}
