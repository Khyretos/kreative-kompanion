#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/main.ts w5e "archiveProject(id, on) is missing"
tsc_ok web/src/main.ts "TS6133: .archiveProject. is declared"
echo ok
