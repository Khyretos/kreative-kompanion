#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/api/types.ts w1 "Project needs archivedAt?: string | null;"
tsc_ok web/src/api/types.ts
echo ok
