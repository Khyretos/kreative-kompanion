#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/styles.css w8 "styles.css misses the PROJ-ARCHIVE rules"
echo ok
