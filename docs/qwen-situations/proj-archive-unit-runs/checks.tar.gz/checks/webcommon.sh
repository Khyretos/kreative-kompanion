# sourced by the PROJ-ARCHIVE web unit checks; run from the repo root
fail() { echo "error: $1: $2"; exit 1; }
NM=$HOME/Docker/Personal-projects/kreative-kompanion/web/node_modules
IMG=mcr.microsoft.com/playwright:v1.63.0-noble
# tsc_ok <file> [allowed error regex]: tsc --noEmit, errors matching the regex are ignored (a later unit uses the name)
tsc_ok() {
  out=$(docker run --rm -u 1000:1000 -e HOME=/tmp -v "$PWD/web:/w" -v "$NM:/w/node_modules:ro" -w /w $IMG npx tsc --noEmit 2>&1)
  if [ -n "$2" ]; then out=$(printf '%s\n' "$out" | grep -Ev "$2"); fi
  bad=$(printf '%s\n' "$out" | grep -E 'error TS' | head -40)
  [ -z "$bad" ] || { printf '%s\n' "$bad"; fail "$1" "tsc --noEmit fails"; }
}
# pw_ok <file> <grep for test titles>: the Playwright spec projarchive (one run at a time: port 5173)
pw_ok() {
  out=$(docker run --rm --network host -u 1000:1000 -e HOME=/tmp -v "$PWD/web:/w" -v "$NM:/w/node_modules:ro" -w /w $IMG npx playwright test tests/projarchive.spec.ts -g "$2" 2>&1); r=$?
  printf '%s\n' "$out" | grep -E '✘|Error:|Expected|Received|expect\(|›|passed|failed' | head -60
  [ $r -eq 0 ] || fail "$1" "Playwright tests/projarchive.spec.ts fails"
}
# has <file> <unit> <message>: the unit's regex from pats.py must match the file
has() { python3 -c "import re,sys; sys.path.insert(0,'/tmp/kk-arch-chk'); from pats import P; sys.exit(0 if re.search(P[sys.argv[2]], open(sys.argv[1]).read(), re.S) else 1)" "$1" "$2" || fail "$1" "$3"; }