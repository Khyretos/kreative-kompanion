#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/main.ts w5d "the tasks pane re-renders on showArchived"
tsc_ok web/src/main.ts
echo ok
