#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/views/sidebar.ts w4a "projects must be the active ones (newest first) plus the archived ones when showArchived"
tsc_ok web/src/views/sidebar.ts "TS6133: .archived. is declared"
echo ok
