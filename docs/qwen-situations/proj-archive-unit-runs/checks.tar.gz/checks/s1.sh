#!/bin/sh
. /tmp/kk-arch-chk/common.sh
F=server/migrations/0131_project_archived.sql
[ -f $F ] || fail $F "the migration file does not exist"
python3 - "$F" <<'PY' || exit 1
import glob, sqlite3, sys
db = sqlite3.connect(":memory:")
for f in sorted(glob.glob("server/migrations/*.sql")):
    try:
        db.executescript(open(f).read())
    except Exception as e:
        print(f"error: {f}: does not apply: {e}"); sys.exit(1)
cols = {r[1]: r[2] for r in db.execute("pragma table_info(projects)")}
if cols.get("archived_at") != "TEXT":
    print(f"error: {sys.argv[1]}: projects has no archived_at TEXT column (columns: {cols})"); sys.exit(1)
db.execute("insert into users (id, name, password_hash, created_at) values ('u','u','x','2026')")
db.execute("insert into projects (id, name, updated_at, user_id) values ('p','p','2026','u')")
if db.execute("select archived_at from projects").fetchone()[0] is not None:
    print(f"error: {sys.argv[1]}: a new project must start with archived_at NULL"); sys.exit(1)
PY
echo "ok"
