#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/api/http.ts w2b "setProjectSettings change needs archived?: boolean after overseer"
tsc_ok web/src/api/http.ts
echo ok
