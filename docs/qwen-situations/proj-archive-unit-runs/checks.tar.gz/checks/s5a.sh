#!/bin/sh
. /tmp/kk-arch-chk/common.sh
cargo_test overseer::tests::archived_projects_leave_the_scan archived_projects_leave_the_scan server/src/overseer.rs
echo ok
