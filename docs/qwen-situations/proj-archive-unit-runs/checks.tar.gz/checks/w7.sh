#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/views/projectpanel.ts w7 "the panel starts with the archived bar"
tsc_ok web/src/views/projectpanel.ts
echo ok
