#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
tsc_ok web/src/main.ts
pw_ok web/src/main.ts "."
echo ok
