#!/bin/sh
. /tmp/kk-arch-chk/common.sh
cargo_test overseer::tests::a_task_proposed_by_name_never_reaches_an_archived_project a_task_proposed_by_name_never_reaches_an_archived_project server/src/overseer.rs
echo ok
