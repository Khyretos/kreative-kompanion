#!/bin/sh
. /tmp/kk-arch-chk/common.sh
python3 - <<'PY' || exit 1
import re, sys
t = open("server/src/api.rs").read()
m = re.search(r"pub struct Project \{(.*?)\n\}", t, re.S)
if not m or not re.search(r"#\[sqlx\(default\)\]\s*pub archived_at: Option<String>,", m.group(1)):
    print("error: server/src/api.rs: struct Project needs `#[sqlx(default)] pub archived_at: Option<String>,` as its last field"); sys.exit(1)
PY
cargo_lib || fail server/src/api.rs "cargo check fails"
echo ok
