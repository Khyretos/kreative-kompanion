#!/bin/sh
. /tmp/kk-arch-chk/common.sh
cargo_test projects::tests::archive_and_unarchive_a_project archive_and_unarchive_a_project server/src/projects.rs
echo ok
