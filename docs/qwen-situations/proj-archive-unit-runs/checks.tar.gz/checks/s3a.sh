#!/bin/sh
. /tmp/kk-arch-chk/common.sh
python3 - <<'PY' || exit 1
import re, sys
t = open("server/src/projects.rs").read()
m = re.search(r"pub struct SettingsBody \{(.*?)\n\}", t, re.S)
if not m or not re.search(r"\barchived: Option<bool>,", m.group(1)):
    print("error: server/src/projects.rs: SettingsBody needs `archived: Option<bool>,`"); sys.exit(1)
PY
cargo_lib || fail server/src/projects.rs "cargo check fails"
echo ok
