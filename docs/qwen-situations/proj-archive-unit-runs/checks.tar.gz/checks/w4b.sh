#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/views/sidebar.ts w4b "the project row needs the archived class, the chip, the project-more button and its menu"
tsc_ok web/src/views/sidebar.ts "TS6133: .archived. is declared"
echo ok
