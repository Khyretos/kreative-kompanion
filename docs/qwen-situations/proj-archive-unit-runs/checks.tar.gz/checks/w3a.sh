#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/state.ts w3a "AppState needs projectMenuId?: string; and showArchived?: boolean;"
tsc_ok web/src/state.ts
echo ok
