#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/views/tasks.ts w6 "the all scope must filter out tasks of archived projects"
tsc_ok web/src/views/tasks.ts
echo ok
