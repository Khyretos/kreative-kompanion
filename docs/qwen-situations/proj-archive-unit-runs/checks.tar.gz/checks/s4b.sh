#!/bin/sh
. /tmp/kk-arch-chk/common.sh
python3 - <<'PY' || exit 1
import re, sys
t = open("server/src/scheduler.rs").read()
m = re.search(r"pub fn spawn\(.*?\n\}", t, re.S)
q = re.search(r'"(SELECT id, user_id FROM projects.*?)"\)', m.group(0), re.S) if m else None
if not q or "archived_at IS NULL" not in q.group(1) or "enabled" not in q.group(1):
    print("error: server/src/scheduler.rs: the project query in fn spawn must keep the enabled filter and add `AND archived_at IS NULL`"); sys.exit(1)
PY
cargo_test scheduler::tests an_archived_project_starts_nothing server/src/scheduler.rs
echo ok
