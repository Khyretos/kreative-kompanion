#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/main.ts w5c "a click outside closes the project menu"
tsc_ok web/src/main.ts
echo ok
