#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/views/sidebar.ts w4c "the Show archived (N) toggle goes right after the projects list"
tsc_ok web/src/views/sidebar.ts
echo ok
