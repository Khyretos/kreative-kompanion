#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/api/client.ts w2a "setProjectSettings change needs archived?: boolean after overseer"
tsc_ok web/src/api/client.ts
echo ok
