#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/api/mock.ts w2c "mock setProjectSettings must take archived and set archivedAt before the emit"
tsc_ok web/src/api/mock.ts
echo ok
