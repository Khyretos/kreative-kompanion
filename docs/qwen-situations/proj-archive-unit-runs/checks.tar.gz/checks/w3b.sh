#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/state.ts w3b "the store starts showArchived from localStorage kk-show-archived inside try/catch"
tsc_ok web/src/state.ts
echo ok
