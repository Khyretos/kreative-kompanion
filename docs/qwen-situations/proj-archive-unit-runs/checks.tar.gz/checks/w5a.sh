#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/main.ts w5a "the sidebar re-renders on projectMenuId and showArchived and places the project menu"
tsc_ok web/src/main.ts
echo ok
