#!/bin/sh
. /tmp/kk-arch-chk/common.sh
python3 - <<'PY' || exit 1
import re, sys
t = open("server/src/api.rs").read()
m = re.search(r"pub async fn projects\(.*?\n\}", t, re.S)
q = re.search(r'"(SELECT .*?)"', m.group(0), re.S) if m else None
if not q or not re.search(r"\barchived_at\b", q.group(1).split("FROM")[0]):
    print("error: server/src/api.rs: the SELECT in fn projects must also select archived_at"); sys.exit(1)
if "WHERE user_id = ?" not in q.group(1) or "archived_at IS" in q.group(1):
    print("error: server/src/api.rs: fn projects must still return every project of the user (no archived filter)"); sys.exit(1)
PY
cargo_lib || fail server/src/api.rs "cargo check fails"
echo ok
