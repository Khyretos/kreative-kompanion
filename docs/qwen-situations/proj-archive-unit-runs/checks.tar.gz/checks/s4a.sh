#!/bin/sh
. /tmp/kk-arch-chk/common.sh
cargo_test scheduler::tests::an_archived_project_starts_nothing an_archived_project_starts_nothing server/src/scheduler.rs
echo ok
