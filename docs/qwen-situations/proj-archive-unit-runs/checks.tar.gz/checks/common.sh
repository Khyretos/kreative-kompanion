# sourced by the PROJ-ARCHIVE unit checks; run from the repo root
export PATH=$HOME/.cargo/bin:$PATH CARGO_TARGET_DIR=/tmp/kk-arch-target
fail() { echo "error: $1: $2"; exit 1; }
cargo_lib() { (cd server && touch src/*.rs && cargo check --quiet 2>&1 | tail -60) ; cd server && cargo check --quiet >/dev/null 2>&1; r=$?; cd ..; return $r; }
# cargo_test <filter> <test name that must say ok>
cargo_test() {
  out=$(cd server && touch src/*.rs && cargo test "$1" 2>&1); r=$?
  # whole compiler error blocks (code lines and notes included), warnings left out; then the test failures
  echo "$out" | awk '/^error/{p=1} /^warning/{p=0} p' | head -80
  echo "$out" | grep -E '^test .*FAILED|panicked|left:|right:' | head -30
  [ $r -eq 0 ] || fail "$3" "cargo test $1 failed"
  echo "$out" | grep -q "test .*$2 \.\.\. ok" || fail "$3" "test $2 did not run"
}
