#!/bin/sh
. /tmp/kk-arch-chk/webcommon.sh
has web/src/views/sidebar.ts w4d "the Move to project list leaves archived projects out unless shown"
tsc_ok web/src/views/sidebar.ts
echo ok
