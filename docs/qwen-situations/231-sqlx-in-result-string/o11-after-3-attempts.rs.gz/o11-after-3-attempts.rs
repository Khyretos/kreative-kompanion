//! PROJ-OVERVIEW: GET /api/projects/{id}/overview, one call with what a project's Overview shows: what it is,
//! where it lives, what it may reach, how far along it is, what happened lately and which models worked on it.
//! Every part comes from existing tables; a part that fails is `null` with its reason in `errors`, never a 500.
use std::collections::HashMap;
use std::time::Duration;

use axum::{
    Extension, Json,
    extract::{Path, State},
};
use serde_json::{Value, json};
use sqlx::SqlitePool;

use crate::{
    AppState,
    auth::User,
    devsettings,
    error::{ApiError, ApiResult},
    scheduler, util,
};

/// The longest `about` text, in bytes.
pub const ABOUT_MAX: usize = 20_000;
/// How much of `about` the planner and a project chat read, in chars.
pub const ABOUT_IN_CONTEXT: usize = 1500;
/// How much of `about` the Overseer reads per project (it scans up to 30 projects), in chars.
pub const ABOUT_IN_SCAN: usize = 300;
/// The cached git remote and branch are read again after this many minutes.
const GIT_STALE_MINUTES: i64 = 60;
/// How long a git read on the repo computer may take.
const GIT_WAIT: Duration = Duration::from_secs(30);

/// One task row for the progress part.
#[derive(Debug, Clone)]
pub struct TaskRow {
    pub id: String,
    pub parent_id: String,
    pub kind: String,
    pub title: String,
    pub state: String,
}

/// The project columns the overview reads.
#[derive(Debug, Clone, sqlx::FromRow)]
pub struct ProjectRow {
    pub id: String,
    pub name: String,
    pub description: String,
    pub about: String,
    pub ptype: String,
    pub kind: String,
    pub source: Option<String>,
    pub links: String,
    pub created_at: Option<String>,
    pub updated_at: String,
    pub archived_at: Option<String>,
    pub repo_folder: Option<String>,
    pub repo_machine_id: Option<String>,
    pub repo_git: String,
    pub dev_settings: String,
    pub scheduler: String,
    pub overseer: bool,
    pub owner: String,
}

/// pure: true when a computer grant on `target` reaches `folder`.
pub fn covers(target: &str, folder: &str) -> bool {
    // "/" trimmed of its slash would be empty: keep the root as "/".
    let trim = |p: &str| -> String {
        let t = p.trim_end_matches('/');
        if t.is_empty() && p.starts_with('/') { "/".into() } else { t.into() }
    };
    let (target, folder) = (trim(target), trim(folder));
    if folder.is_empty() || !target.starts_with('/') {
        return false;
    }
    target == "/" || target == folder || folder.starts_with(&format!("{target}/"))
}

/// pure: the project text a prompt gets: the description, then at most `max` chars of `about`.
pub fn with_about(description: &str, about: &str, max: usize) -> String {
    let d = description.trim();
    let a = about.trim();
    if a.is_empty() {
        return d.to_string();
    }
    let mut cut = a.chars().take(max).collect::<String>();
    if a.len() > max {
        cut.push('…');
    }
    if d.is_empty() {
        cut
    } else {
        format!("{d}\n\n{cut}")
    }
}

/// pure: one activity line. `src` is "task" (a task event), "run" (a task run) or "chat".
pub fn activity_what(src: &str, kind: &str, title: &str, detail: &str) -> String {
    match src {
        "task" => match kind {
            "created" => format!("Task added: {}", title),
            "changed" => format!("Task changed: {}", title),
            "forge" => {
                let v: serde_json::Value = detail.parse().unwrap_or_default();
                if let Some(to) = v.get("state").and_then(|s| s.get("to")).and_then(|t| t.as_str()) {
                    if to == "done" {
                        format!("PR merged: {}", title)
                    } else {
                        format!("PR update: {}", title)
                    }
                } else {
                    format!("PR update: {}", title)
                }
            }
            _ => format!("{}: {}", kind.replace('_', " "), title),
        },
        "run" => format!("Run {}: {}", kind, title),
        _ => format!("Chat: {}", title),
    }
}

/// pure: progress counts from the task rows; `deps` holds (task_id, depends_on) pairs.
pub fn progress(rows: &[TaskRow], deps: &[(String, String)]) -> Value {
    let state: HashMap<&str, &str> = rows.iter().map(|r| (r.id.as_str(), r.state.as_str())).collect();
    let tasks: Vec<&TaskRow> = rows.iter().filter(|r| r.kind == "task").collect();
    let count = |states: &[&str]| tasks.iter().filter(|t| states.contains(&t.state.as_str())).count();
    let goals: Vec<Value> = rows
        .iter()
        .filter(|g| g.kind == "goal")
        .filter_map(|g| {
            let mine: Vec<&&TaskRow> = tasks.iter().filter(|t| t.parent_id == g.id).collect();
            let done = mine.iter().filter(|t| t.state == "done").count();
            (!mine.is_empty()).then(|| json!({ "title": g.title, "done": done, "total": mine.len() }))
        })
        .collect();
    // A dependency on a task that is not in the rows counts as done.
    let ready = |id: &str| deps.iter().filter(|(t, _)| t == id).all(|(_, on)| state.get(on.as_str()).is_none_or(|s| *s == "done"));
    let queued: Vec<&&TaskRow> = tasks.iter().filter(|t| t.state == "queued").collect();
    let (first, later): (Vec<&&TaskRow>, Vec<&&TaskRow>) = queued.into_iter().partition(|t| ready(&t.id));
    let next: Vec<Value> = first
        .iter()
        .map(|t| (t, true))
        .chain(later.iter().map(|t| (t, false)))
        .take(3)
        .map(|(t, r)| json!({ "id": t.id, "title": t.title, "ready": r }))
        .collect();
    json!({
        "done": count(&["done"]), "total": tasks.len(), "running": count(&["running"]),
        "needsYou": count(&["needs_input", "failed", "refused"]), "inReview": count(&["in_review"]),
        "goals": goals, "next": next,
    })
}

/// pure: the remote and branch from the output of `git remote get-url origin; git branch --show-current`.
pub fn parse_git(output: &str) -> Option<(String, String)> {
    let lines: Vec<&str> = output.lines().collect();
    let exit_idx = lines.iter().rposition(|l| l.trim_start().starts_with("exit:"));
    
    if let Some(idx) = exit_idx {
        let exit_line = lines[idx].trim();
        let num_part = exit_line.strip_prefix("exit:").map(|s| s.trim());
        if num_part != Some("0") {
            return None;
        }
    } else {
        return None;
    }
    
    let body_lines: Vec<String> = lines.iter()
        .take(if let Some(idx) = exit_idx { idx } else { lines.len() })
        .filter_map(|l| {
            let trimmed = l.trim();
            if trimmed.is_empty() {
                None
            } else {
                Some(trimmed.to_string())
            }
        })
        .collect();
    
    if body_lines.len() < 2 {
        return None;
    }
    
    let remote = body_lines[0].clone();
    let branch = body_lines[1].clone();
    
    // Drop "user:token@" between "://" and the host (only when the '@' comes before the next '/').
    let clean_remote = match remote.find("://") {
        Some(pos) => {
            let after = &remote[pos + 3..];
            match after.find('@') {
                Some(at) if after.find('/').is_none_or(|slash| at < slash) => format!("{}{}", &remote[..pos + 3], &after[at + 1..]),
                _ => remote.clone(),
            }
        }
        None => remote.clone(),
    };

    Some((clean_remote, branch))
}

/// Reads the repo's git remote and branch on its computer (a shell job under the computer's grants) and
/// caches them in `projects.repo_git`. Runs in the background; a failure leaves the cache as it was.
pub async fn refresh_git(s: AppState, user_id: String, project_id: String, machine_id: String, folder: String) {
    s.host.watch(&user_id);
    let job = match crate::access::queue_job(&s.db, &machine_id, &user_id, &json!({ "tool": "shell", "cwd": folder, "command": "git remote get-url origin; git branch --show-current" }), None).await {
        Ok(j) => j,
        Err(_) => return,
    };

    let start = util::now();
    loop {
        tokio::time::sleep(Duration::from_millis(500)).await;
        let row: Option<(String, Option<String>)> = sqlx::query_as("SELECT state, result FROM machine_jobs WHERE id = ?")
            .bind(&job)
            .fetch_optional(&s.db)
            .await.ok().flatten();
        if let Some((state, result)) = row {
            if state == "done" {
                if let Some((remote, branch)) = parse_git(&result.unwrap_or_default()) {
                    let _ = sqlx::query("UPDATE projects SET repo_git = ? WHERE id = ? AND user_id = ?")
                        .bind(json!({ "remote": remote, "branch": branch, "at": util::now() }).to_string())
                        .bind(&project_id)
                        .bind(&user_id)
                        .execute(&s.db)
                        .await;
                }
                return;
            } else if state == "failed" || state == "refused" {
                return;
            }
        }
    }
}

/// The project row with its owner's name; None when it is not this user's.
pub async fn load(db: &SqlitePool, user_id: &str, project_id: &str) -> sqlx::Result<Option<ProjectRow>> {
    sqlx::query_as::<_, ProjectRow>(
        "SELECT p.id, p.name, p.description, p.about, p.ptype, p.kind, p.source, p.links, COALESCE(p.created_at, p.updated_at) AS created_at, p.updated_at, p.archived_at, p.repo_folder, p.repo_machine_id, p.repo_git, p.dev_settings, p.scheduler, p.overseer, COALESCE(u.name, '') AS owner FROM projects p LEFT JOIN users u ON u.id = p.user_id WHERE p.id = ? AND p.user_id = ?",
    )
    .bind(project_id)
    .bind(user_id)
    .fetch_optional(db)
    .await
}

/// Where it lives: the repo computer, the folder and the cached git remote and branch.
async fn where_part(s: &AppState, user_id: &str, p: &ProjectRow) -> Result<Value, String> {
    let none = || json!({ "machine": null, "folder": p.repo_folder, "git": null, "gitState": "none" });
    let Some(machine_id) = p.repo_machine_id.as_deref() else { return Ok(none()) };
    let row: Option<(String, String, bool)> = sqlx::query_as::<_, (String, String, bool)>(
        "SELECT id, name, last_seen IS NOT NULL AND (julianday('now') - julianday(last_seen)) * 86400 <= 90 FROM machines WHERE id = ? AND user_id = ?",
    )
    .bind(machine_id)
    .bind(user_id)
    .fetch_optional(s.db)
    .await
    .map_err(|e| e.to_string())?;
    let Some((id, name, online)) = row else { return Ok(none()) };
    let cache: Value = serde_json::from_str(&p.repo_git).unwrap_or(Value::Null);
    let git = if cache.is_object() { cache } else { Value::Null };
    let stale = git["at"].as_str().is_none_or(|at| at < util::minutes_ago(GIT_STALE_MINUTES).as_str());
    let state = match (&p.repo_folder, online && stale) {
        (Some(folder), true) => {
            tokio::spawn(refresh_git(s.clone(), user_id.to_string(), p.id.clone(), id.clone(), folder.clone()));
            "reading"
        }
        _ if !git.is_null() => "known",
        _ => "unknown",
    };
    Ok(json!({
        "machine": { "id": id, "name": name, "online": online, "os": s.host.os(&id) },
        "folder": p.repo_folder, "git": git, "gitState": state,
    }))
}

/// What it can reach: computer grants covering the repo folder, active MCP grants, knowledge, assets, commands.
async fn access_part(s: &AppState, user_id: &str, p: &ProjectRow) -> Result<Value, String> {
    let mut grants = Vec::new();
    if let (Some(machine_id), Some(folder)) = (&p.repo_machine_id, &p.repo_folder) {
        let rows = sqlx::query_as::<_, (String, String, Option<String>)>(
            "SELECT target, rights, expires FROM machine_grants WHERE machine_id = ? ORDER BY target",
        )
        .bind(machine_id)
        .fetch_all(s.db)
        .map_err(|e| e.to_string())?;

        for (target, rights, expires) in rows {
            if covers(&target, folder) {
                let rights_list: Vec<String> = serde_json::from_str(&rights).unwrap_or_default();
                grants.push(json!({
                    "target": target,
                    "rights": rights_list,
                    "expires": expires
                }));
            }
        }
    }

    let mcp_rows = sqlx::query_as::<_, (String, String, Option<String>)>(
        "SELECT server, tool, expires FROM mcp_grants WHERE user_id = ? AND expires > ?",
    )
    .bind(user_id)
    .bind(util::now())
    .fetch_all(s.db)
    .map_err(|e| e.to_string())?;

    let mcp: Vec<Value> = mcp_rows
        .into_iter()
        .map(|(server, tool, expires)| json!({"server": server, "tool": tool, "expires": expires}))
        .collect();

    let knowledge_rows = sqlx::query_as::<_, (i64, String)>(
        "SELECT c.id, c.name FROM knowledge_project kp JOIN knowledge_collection c ON c.id = kp.collection_id WHERE kp.project_id = ? ORDER BY c.name",
    )
    .bind(p.id)
    .fetch_all(s.db)
    .map_err(|e| e.to_string())?;

    let knowledge: Vec<Value> = knowledge_rows
        .into_iter()
        .map(|(id, name)| json!({"id": id, "name": name}))
        .collect();

    let asset_count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM project_asset WHERE project_id = ?")
        .bind(p.id)
        .fetch_one(s.db)
        .map_err(|e| e.to_string())?;

    let mut commands = Vec::new();
    if let Some(dev_settings) = &p.dev_settings {
        if let Ok(dev) = devsettings::Settings::parse(dev_settings) {
            for kind in ["build", "test", "run", "deploy"] {
                if let Some(cmd) = dev.command(kind) {
                    let last = dev.last.get(kind).map(|lr| json!(lr)).or_else(|| {
                        if kind == "deploy" { None } else { Some(json!(null)) }
                    });
                    commands.push(json!({
                        "kind": kind,
                        "command": cmd,
                        "last": last,
                        "fromHere": kind != "deploy"
                    }));
                }
            }
        }
    }

    Ok(json!({
        "grants": grants,
        "mcp": mcp,
        "knowledge": knowledge,
        "assets": asset_count,
        "commands": commands
    }))
}

/// Progress: counts from the tasks plus the last merged PR.
async fn progress_part(db: &SqlitePool, user_id: &str, project_id: &str) -> Result<Value, String> {
    todo!("unit o12")
}

/// The last 10 events across task events, runs and the project's chats, newest first.
async fn activity_part(db: &SqlitePool, user_id: &str, project_id: &str) -> Result<Value, String> {
    todo!("unit o13")
}

/// Models used by the project's runs in the last 30 days: runs, tokens and model minutes per model.
async fn ai_part(db: &SqlitePool, user_id: &str, project_id: &str) -> Result<Value, String> {
    todo!("unit o14")
}

/// GET /api/projects/{id}/overview (owner only; anyone else gets 404).
pub async fn get(State(s): State<AppState>, Extension(u): Extension<User>, Path(id): Path<String>) -> ApiResult<Json<Value>> {
    todo!("unit o15")
}

#[cfg(test)]
#[path = "overview_tests.rs"]
mod tests;
