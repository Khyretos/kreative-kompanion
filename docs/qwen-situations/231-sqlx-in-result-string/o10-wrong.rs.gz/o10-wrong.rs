async fn where_part(s: &AppState, user_id: &str, p: &ProjectRow) -> Result<Value, String> {
    let machine: Option<(String, String, bool)> = sqlx::query_as::<_, (String, String, bool)>(
        "SELECT id, name, last_seen IS NOT NULL AND (julianday('now') - julianday(last_seen)) * 86400 <= 90 as online FROM machines WHERE id = ? AND user_id = ?",
    )
    .bind(p.repo_machine_id.as_deref().unwrap_or(""))
    .bind(user_id)
    .fetch_optional(&s.db)
    .await?;

    let machine_obj = if let Some((id, name, online)) = machine {
        let os = s.host.os(&id);
        json!({ "id": id, "name": name, "online": online, "os": os })
    } else {
        json!(null)
    };

    let git = if let Some(cache) = &p.repo_git {
        let val: serde_json::Value = serde_json::from_str(cache).map_err(|_| "bad JSON")?;
        if !val.is_object() {
            json!(null)
        } else {
            let at = val.get("at").and_then(|v| v.as_str()).unwrap_or("");
            let stale_threshold = util::minutes_ago(GIT_STALE_MINUTES);
            let stale = at.is_empty() || at < stale_threshold;
            let git_state = if s.host.online() && stale && p.repo_folder.is_some() {
                let _ = tokio::spawn(async move {
                    refresh_git(s.clone(), user_id.to_string(), p.id.clone(), id, p.repo_folder.clone()).await.ok();
                }).await;
                "reading"
            } else if !stale {
                "known"
            } else {
                "unknown"
            };
            json!({ "remote": val.get("remote"), "branch": val.get("branch"), "at": at, "state": git_state })
        }
    } else {
        json!(null)
    };

    Ok(json!({ "machine": machine_obj, "folder": p.repo_folder, "git": git, "gitState": git.get("state").unwrap_or(&json!("none")) }))
}

