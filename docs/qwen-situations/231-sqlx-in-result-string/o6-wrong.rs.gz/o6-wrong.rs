pub fn progress(rows: &[TaskRow], deps: &[(String, String)]) -> Value {
    let mut map = serde_json::Map::new();

    // Build state lookup
    let mut state_map: HashMap<&str, &str> = HashMap::new();
    for row in rows {
        state_map.insert(row.id.as_str(), row.state.as_str());
    }

    // Count tasks by state
    let mut done = 0;
    let mut running = 0;
    let mut needs_you = 0;
    let mut failed = 0;
    let mut in_review = 0;

    // Collect goals with their tasks
    let mut goals: Vec<(usize, &TaskRow)> = Vec::new();
    let mut goal_tasks: HashMap<String, Vec<usize>> = HashMap::new();

    for (idx, row) in rows.iter().enumerate() {
        if row.kind == "goal" {
            let mut tasks = Vec::new();
            for other in rows {
                if other.parent_id == row.id.clone() {
                    tasks.push(idx);
                }
            }
            if !tasks.is_empty() {
                goals.push((idx, row));
                goal_tasks.insert(row.id.clone(), tasks);
            }
        } else if row.kind == "task" {
            match row.state.as_str() {
                "done" => done += 1,
                "running" => running += 1,
                "needs_input" | "failed" | "refused" => needs_you += 1,
                "in_review" => in_review += 1,
                _ => {}
            }
        }
    }

    let total = done + running + needs_you + failed + in_review;

    // Prepare next tasks
    let mut next_candidates: Vec<(usize, &TaskRow)> = Vec::new();
    for (idx, row) in rows.iter().enumerate() {
        if row.kind == "task" && row.state == "queued" {
            next_candidates.push((idx, row));
        }
    }

    // Sort next candidates: ready first, then not-ready, both in row order
    next_candidates.sort_by(|a, b| {
            let a_ready = deps.iter().all(|(id, dep)| {
                if *id == a.1.id {
                    if let Some(dep_state) = state_map.get(dep.as_str()) {
                        *dep_state == "done"
                    } else {
                        true
                    }
                } else {
                    true
                }
            });
            let b_ready = deps.iter().all(|(id, dep)| {
                if *id == b.1.id {
                    if let Some(dep_state) = state_map.get(dep.as_str()) {
                        *dep_state == "done"
                    } else {
                        true
                    }
                } else {
                    true
                }
            });
        a_ready.cmp(&b_ready).then_with(|| a.0.cmp(&b.0))
    });

    let mut next: Vec<Value> = Vec::new();
    for (idx, row) in next_candidates.iter().take(3) {
        let is_ready = deps.iter().all(|(id, dep)| {
            if *id == row.id {
                if let Some(dep_state) = state_map.get(dep.as_str()) {
                    *dep_state == "done"
                } else {
                    true
                }
            } else {
                true
            }
        });
        next.push(json!({
            "id": row.id,
            "title": row.title,
            "ready": is_ready
        }));
    }

    json!({
        "done": done,
        "total": total,
        "running": running,
        "needsYou": needs_you,
        "failed": failed,
        "inReview": in_review,
        "goals": goals.iter().map(|(_, g)| {
            let tasks = &goal_tasks[g.id];
            let done_count = tasks.iter().filter(|&&i| rows[i].state == "done").count();
            json!({
                "title": g.title,
                "done": done_count,
                "total": tasks.len()
            })
        }).collect::<Vec<_>>(),
        "next": next
    })
}

