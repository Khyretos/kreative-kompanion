// The real client: talks to a Kompanion server over HTTPS (same origin) with
// a session cookie. Live updates arrive as server-sent events.
import type { KompanionApi, ServerEvent } from "./client";
import type {
  AdminSettings, NotificationPrefs, ThemeChoice, TaskState, Chat, DaySummary, MachineStats, Message, ModelProvider, Project, RoleAssignment, SearchResult, Server, ServerStatus, Task,
} from "./types";

// STU-N1: a type with a "negative" parameter gets the Leave out field; its default words show as a hint.
function negativeDefault(params?: { name: string; default?: unknown }[]): string | undefined {
  const n = params?.find((p) => p.name === "negative");
  return n ? (typeof n.default === "string" ? n.default : "") : undefined;
}

export class ApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
  }
}

/** STU-02: the Studio's audio types (HeartMuLa and MOSS on the server). */
export const AUDIO_TYPES: import("../views/studio").StudioType[] = [
  { name: "music", label: "Music", hint: "A song or a loop, with optional lyrics", sizes: [], order: 7, audio: "music", seconds: { min: 5, max: 240, default: 30 } },
  { name: "sfx", label: "Sound effect", hint: "A short sound for a game", sizes: [], order: 8, audio: "sfx", seconds: { min: 1, max: 30, default: 4 } },
];

export class HttpApi implements KompanionApi {
  private source?: EventSource;
  private listeners = new Set<(ev: ServerEvent) => void>();

  constructor(private base = "") {}

  private async request<T>(method: string, path: string, body?: unknown): Promise<T> {
    const raw = body instanceof Blob;
    const form = body instanceof FormData; // STU-01d: multipart, the browser sets the boundary
    const res = await fetch(`${this.base}/api${path}`, {
      method,
      credentials: "same-origin",
      headers: {
        ...(body === undefined || form ? {} : { "Content-Type": raw ? (body as Blob).type || "application/octet-stream" : "application/json" }),
        // Required by the server for anything that changes state (CSRF guard).
        "X-Kompanion": "1",
      },
      body: body === undefined ? undefined : form ? (body as FormData) : raw ? (body as Blob) : JSON.stringify(body),
    });
    if (!res.ok) {
      let message = `The server answered ${res.status}.`;
      try {
        message = (await res.json()).error ?? message;
      } catch { /* not JSON */ }
      throw new ApiError(message, res.status);
    }
    if (res.status === 204 || res.status === 202) return undefined as T;
    return res.json() as Promise<T>;
  }

  async discover(): Promise<Server[]> {
    return []; // Local-network discovery needs the native app.
  }

  async connect(url: string): Promise<Server> {
    const s = await this.status();
    return { url, name: new URL(url).hostname, version: s.version };
  }

  status() { return this.request<ServerStatus>("GET", "/status"); }
  setup(code: string, name: string, password: string) {
    return this.request<void>("POST", "/setup", { code, name, password });
  }
  login(name: string, password: string) { return this.request<void>("POST", "/login", { name, password }); }
  async logout() { return (await this.request<{ redirect?: string | null }>("POST", "/logout")).redirect ?? null; }
  getNotifications() { return this.request<NotificationPrefs>("GET", "/me/notifications"); }
  setNotifications(p: NotificationPrefs) { return this.request<void>("PUT", "/me/notifications", p); }
  setGpuPins(pins: string[]) { return this.request<void>("PUT", "/me/prefs", { gpuPins: pins }); }
  setOverseer(change: { overseerName?: string; overseerInterject?: boolean }) { return this.request<void>("PUT", "/me/prefs", change); }
  overseerTasks(b: { project: string; projectId: string | null; tasks: { title: string; description: string }[] }) { return this.request<{ projectId: string }>("POST", "/overseer/tasks", b); }
  interject(taskId: string, text: string) { return this.request<void>("POST", `/tasks/${encodeURIComponent(taskId)}/interject`, { text }); }
  setCardStyle(style: import("../core/cardtypes").CardStyle) { return this.request<void>("PUT", "/me/prefs", { cardStyle: style }); }
  setMachinesRefresh(seconds: number) { return this.request<void>("PUT", "/me/prefs", { machinesRefresh: seconds }); }
  pairMachine(name: string) { return this.request<{ id: string; name: string; token: string }>("POST", "/machines", { name }); }
  listGrants(machineId: string) { return this.request<import("../views/access").GrantView[]>("GET", `/machines/${encodeURIComponent(machineId)}/grants`); }
  addGrant(machineId: string, target: string, rights: string[], expiresHours?: number) {
    return this.request<void>("POST", `/machines/${encodeURIComponent(machineId)}/grants`, { target, rights, expires_hours: expiresHours ?? null });
  }
  revokeGrant(machineId: string, target: string) {
    return this.request<void>("POST", `/machines/${encodeURIComponent(machineId)}/grants/revoke`, { target });
  }
  renewGrant(machineId: string, target: string, expiresHours: number | null) {
    return this.request<void>("POST", `/machines/${encodeURIComponent(machineId)}/grants/renew`, { target, expires_hours: expiresHours });
  }

  accessHistory() { return this.request<import("../views/access").AccessEvent[]>("GET", "/access"); }
  pairCode(name: string) { return this.request<{ code: string; expiresAt: string }>("POST", "/machines/pair-code", { name }); }
  unpairMachine(id: string) { return this.request<void>("DELETE", `/machines/${encodeURIComponent(id)}`); }
  updateRunner(id: string) { return this.request<void>("POST", `/machines/${encodeURIComponent(id)}/jobs`, { tool: { tool: "self_update" } }); }
  watchMachines() { return this.request<void>("POST", "/machines/live"); }
  setTheme(theme: ThemeChoice) { return this.request<void>("PUT", "/me/theme", { theme }); }
  getAdmin() { return this.request<{ settings: AdminSettings; smtpPasswordSet: boolean }>("GET", "/admin/settings"); }
  saveAdmin(settings: AdminSettings) { return this.request<AdminSettings>("PUT", "/admin/settings", settings); }
  uploadLogo(file: File) { return this.request<void>("PUT", "/admin/logo", file); }
  removeLogo() { return this.request<void>("DELETE", "/admin/logo"); }
  testMail(to: string) { return this.request<void>("POST", "/admin/test-mail", { to }); }

  listProjects() { return this.request<Project[]>("GET", "/projects"); }
  setProjectSettings(projectId: string, change: import("./types").ProjectSettingsChange) {
    return this.request<void>("PATCH", `/projects/${encodeURIComponent(projectId)}/settings`, change);
  }
  getOverview(projectId: string) {
    return this.request<import("./types").ProjectOverview>("GET", `/projects/${encodeURIComponent(projectId)}/overview`);
  }
  getDevSettings(projectId: string) {
    return this.request<import("./types").DevSettingsView>("GET", `/projects/${encodeURIComponent(projectId)}/dev-settings`);
  }
  putDevSettings(projectId: string, s: Omit<import("./types").DevSettings, "last">) {
    return this.request<void>("PUT", `/projects/${encodeURIComponent(projectId)}/dev-settings`, s);
  }
  runDevCommand(projectId: string, kind: "build" | "test" | "run") {
    return this.request<void>("POST", `/projects/${encodeURIComponent(projectId)}/dev-settings/run/${kind}`);
  }
  projectAssets(projectId: string) {
    return this.request<import("../views/projectpanel").ProjectAsset[]>("GET", `/projects/${encodeURIComponent(projectId)}/assets`);
  }
  attachAsset(projectId: string, assetId: number) {
    return this.request<void>("POST", `/projects/${encodeURIComponent(projectId)}/assets`, { assetId });
  }
  detachAsset(projectId: string, assetId: number) {
    return this.request<void>("DELETE", `/projects/${encodeURIComponent(projectId)}/assets/${assetId}`);
  }
  listChats() { return this.request<Chat[]>("GET", "/chats"); }
  async search(q: string) { return (await this.request<{ results: SearchResult[] }>("GET", `/search?q=${encodeURIComponent(q)}`)).results; }
  listMessages(chatId: string) { return this.request<Message[]>("GET", `/chats/${encodeURIComponent(chatId)}/messages`); }
  listTasks() { return this.request<Task[]>("GET", "/tasks"); }
  listProviders() { return this.request<ModelProvider[]>("GET", "/providers"); }
  listRoles() { return this.request<RoleAssignment[]>("GET", "/roles"); }
  setRole(a: RoleAssignment) { return this.request<void>("PUT", "/roles", a); }
  listMachines() { return this.request<MachineStats[]>("GET", "/machines"); }
  async today(): Promise<DaySummary> {
    return { tasks: 0, localTokens: 0, cloudTokens: 0, cloudCostEur: 0, energyKwh: 0 };
  }

  createChat(title: string, projectId?: string) { return this.request<Chat>("POST", "/chats", { title, projectId }); }
  openThread(projectId: string) { return this.request<{ chatId: string }>("POST", `/projects/${encodeURIComponent(projectId)}/thread`).then((r) => r.chatId); }
  updateChat(chatId: string, change: { title?: string; pinned?: boolean; archived?: boolean; projectId?: string; effort?: import("./types").Effort; mcp?: string[]; overseer?: boolean }) {
    return this.request<void>("PATCH", `/chats/${encodeURIComponent(chatId)}`, change);
  }
  createTask(t: { projectId: string; title: string; description: string; state?: TaskState; chatId?: string; effort?: import("./types").Effort } & import("./types").TaskTreeChange) {
    return this.request<Task>("POST", "/tasks", t);
  }
  updateTask(id: string, change: { title?: string; description?: string; state?: TaskState; effort?: import("./types").Effort } & import("./types").TaskTreeChange) {
    return this.request<Task>("PATCH", `/tasks/${encodeURIComponent(id)}`, change);
  }
  deleteTask(id: string) { return this.request<void>("DELETE", `/tasks/${encodeURIComponent(id)}`); }
  reorderTasks(projectId: string, ids: string[]) { return this.request<void>("PUT", "/tasks/order", { projectId, ids }); }
  makeProjectInternal(projectId: string) {
    return this.request<void>("PATCH", `/projects/${encodeURIComponent(projectId)}`, { kind: "internal" });
  }
  deleteChat(chatId: string) { return this.request<void>("DELETE", `/chats/${encodeURIComponent(chatId)}`); }
  send(chatId: string, text: string, machineId?: string, effort?: import("./types").Effort, attachments?: import("../core/attachments").Attached[]) {
    return this.request<void>("POST", `/chats/${encodeURIComponent(chatId)}/messages`, { text, machine_id: machineId ?? null, effort, attachments: attachments ?? [] });
  }
  attach(chatId: string, file: File) {
    return this.request<import("../core/attachments").Attached>("POST", `/chats/${encodeURIComponent(chatId)}/attachments?name=${encodeURIComponent(file.name)}`, file);
  }
  listActions(chatId: string) { return this.request<import("./client").PcAction[]>("GET", `/chats/${encodeURIComponent(chatId)}/actions`); }
  listLessons(chatId: string) { return this.request<import("./client").Lesson[]>("GET", `/chats/${encodeURIComponent(chatId)}/lessons`); }
  stopAction(id: string) { return this.request<void>("POST", `/actions/${encodeURIComponent(id)}/stop`); }
  taskRuns(taskId: string) { return this.request<{ id: string; startedAt: string; endedAt: string | null; status: string; step: string | null; effort?: string | null; effortPicked?: boolean }[]>("GET", `/tasks/${encodeURIComponent(taskId)}/runs`); }
  taskCosts(taskId: string) { return this.request<import("./types").CostLine | null>("GET", `/tasks/${encodeURIComponent(taskId)}/costs`); }
  weeklyCosts() { return this.request<import("./types").WeeklyCosts>("GET", "/costs/weekly"); }
  stopTask(id: string) { return this.request<void>("POST", `/tasks/${encodeURIComponent(id)}/stop`); }
  checkFolder(machineId: string, path: string) {
    return this.request<{ state: "ok" | "nogrant" | "missing" | "notfolder" | "noanswer"; path: string; folders?: string[]; files?: number; message?: string }>("POST", `/machines/${encodeURIComponent(machineId)}/folder`, { path });
  }
  startTask(id: string, machineId: string, folder: string, check: string, testsMayChange = false, effort?: import("./types").Effort) {
    return this.request<void>("POST", `/tasks/${encodeURIComponent(id)}/start`, { machine_id: machineId, folder, check, tests_may_change: testsMayChange, effort });
  }
  listActivity() { return this.request<import("../views/activity").ActivityItem[]>("GET", "/activity"); }
  getCapabilities() { return this.request<import("../views/capabilities").Capabilities>("GET", "/capabilities"); }
  knowledge() { return this.request<{ collections: import("../views/knowledge").KCollection[] }>("GET", "/knowledge"); }
  createKnowledge(name: string) { return this.request<{ id: string; name: string }>("POST", "/knowledge", { name }); }
  deleteKnowledge(id: string) { return this.request<void>("DELETE", `/knowledge/${encodeURIComponent(id)}`); }
  setKnowledgeProjects(id: string, projects: string[]) { return this.request<void>("PUT", `/knowledge/${encodeURIComponent(id)}/projects`, { projects }); }
  uploadKnowledge(id: string, file: File, onProgress: (pct: number) => void): Promise<{ id: number; name: string; chunks: number }> {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${this.base}/api/knowledge/${encodeURIComponent(id)}/docs?name=${encodeURIComponent(file.name)}`);
    xhr.withCredentials = true;
    xhr.setRequestHeader("X-Kompanion", "1");
    xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
    return new Promise((resolve, reject) => {
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          onProgress(100);
          try { resolve(JSON.parse(xhr.responseText)); } catch { reject(new ApiError("The server answered " + xhr.status + ".", xhr.status)); }
        } else {
          let message = `The server answered ${xhr.status}.`;
          try { message = (JSON.parse(xhr.responseText) as { error: string }).error ?? message; } catch { /* not JSON */ }
          reject(new ApiError(message, xhr.status));
        }
      };
      xhr.onerror = () => reject(new ApiError("The upload failed: the server could not be reached.", 0));
      xhr.send(file);
    });
  }
  deleteKnowledgeDoc(id: string, doc: number) { return this.request<void>("DELETE", `/knowledge/${encodeURIComponent(id)}/docs/${doc}`); }
  knowledgeDocs(id: string, q: string, offset: number) { return this.request<{ documents: import("../views/knowledge").KDoc[]; total: number }>("GET", `/knowledge/${encodeURIComponent(id)}/docs?q=${encodeURIComponent(q)}&offset=${offset}`); }
  knowledgeDoc(id: string, doc: number) { return this.request<{ id: number; name: string; text: string }>("GET", `/knowledge/${encodeURIComponent(id)}/docs/${doc}`); }
  async studioTypes() {
    const all = await this.request<{ name: string; problems?: string[]; face?: boolean; params?: { name: string; choices?: string[]; adult?: string[]; default?: unknown }[]; studio?: { label: string; hint: string; sizes: string[]; order: number; refine?: boolean } | null }[]>("GET", "/studio/workflows");
    return all.filter((w) => w.studio && !w.studio.refine).map((w): import("../views/studio").StudioType => ({ name: w.name, label: w.studio!.label, hint: w.studio!.hint, sizes: w.studio!.sizes.length ? w.studio!.sizes : ["square"], order: w.studio!.order, warning: w.problems?.length ? w.problems.join("; ") : undefined, ratings: w.params?.find((p) => p.name === "rating")?.choices, adultRatings: w.params?.find((p) => p.name === "rating")?.adult, face: !!w.face, negative: negativeDefault(w.params), helmet: !!w.params?.some((p) => p.name === "helmet") }))
      .sort((a, b) => a.order - b.order)
      // STU-02: music and sound effects are apps, not workflows.
      .concat(AUDIO_TYPES);
  }
  studioAudio(kind: "music" | "sfx", prompt: string, lyrics: string, seconds: number) { return this.request<{ ids: string[] }>("POST", "/studio/audio", { kind, prompt, lyrics, seconds }); }
  // STU-01d: with a face photo the form goes as multipart.
  studioMake(type: string, prompt: string, size: string, count: 1 | 4, rating?: string, face?: { file: File; weight: number }, negative?: string, params?: Record<string, string>) {
    if (face) {
      const f = new FormData();
      f.append("type", type);
      f.append("prompt", prompt);
      f.append("size", size);
      f.append("count", String(count));
      if (rating) f.append("rating", rating);
      if (negative) f.append("negative", negative);
      if (params) f.append("params", JSON.stringify(params));
      f.append("face", face.file);
      f.append("face_weight", String(face.weight));
      return this.request<{ ids: string[] }>("POST", "/studio/make", f);
    }
    return this.request<{ ids: string[] }>("POST", "/studio/make", { type, prompt, size, count, rating, negative: negative || undefined, params });
  }
  studioMine() { return this.request<import("../views/studio").StudioRun[]>("GET", "/studio/mine"); }
  studioToAssets(runId: string, project: string, n = 0) {
    return this.request<{ assetId: number; project: string; name: string }>("POST", `/studio/runs/${encodeURIComponent(runId)}/to-assets`, { project, n });
  }
  // STU-D1: delete finished runs and their files (ids, or every failed one with failed = true).
  studioDelete(ids: string[], failed = false) { return this.request<{ deleted: string[]; skipped: string[]; keptFiles: number }>("POST", "/studio/runs/delete", { ids, failed }); }
  setStudioTarget(target: string) { return this.request<void>("PUT", "/studio/target", { target }); }
  setGpuMode(machine: string, mode: import("../views/capabilities").GpuModeName) { return this.request<void>("PUT", `/gpus/modes/${encodeURIComponent(machine)}`, { mode }); }
  gpuTimeline(hours: 1 | 24) { return this.request<import("../views/gputimeline").TlGpu[]>("GET", `/gpus/timeline?hours=${hours}`); }
  voiceInfo() { return this.request<{ enabled: boolean; voices: { id: string; label: string }[] }>("GET", "/voice"); }
  async transcribe(audio: Blob, lang: string) {
    return (await this.request<{ text: string }>("POST", `/voice/transcribe${lang ? `?lang=${lang}` : ""}`, audio)).text;
  }
  async speak(text: string, voice: string) {
    const res = await fetch(`${this.base}/api/voice/speak`, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-Kompanion": "1" },
      body: JSON.stringify({ text, voice }),
    });
    if (!res.ok) {
      let message = `The server answered ${res.status}.`;
      try { message = (await res.json()).error ?? message; } catch { /* not JSON */ }
      throw new ApiError(message, res.status);
    }
    return res.blob();
  }
    const res = await fetch(`${this.base}/api/voice/speak`, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-Kompanion": "1" },
      body: JSON.stringify({ text, voice }),
    });
    if (!res.ok) {
      let message = `The server answered ${res.status}.`;
      try { message = (await res.json()).error ?? message; } catch { /* not JSON */ }
      throw new ApiError(message, res.status);
    }
    return res.blob();
  }
  getSkill(id: string, layer?: string) { return this.request<{ id: string; text: string; layer?: string }>("GET", `/capabilities/skill?id=${encodeURIComponent(id)}${layer ? `&layer=${encodeURIComponent(layer)}` : ""}`); }
  skillHistory(layer: string, file: string) { return this.request<{ commits: import("../views/capabilities").SkillCommit[] }>("GET", `/capabilities/skill/history?layer=${encodeURIComponent(layer)}&file=${encodeURIComponent(file)}`); }
  saveSkill(layer: string, file: string, text: string, message: string) { return this.request<{ commit: string }>("PUT", "/capabilities/skill", { layer, file, text, message }); }
  moveLesson(from: string, to: string, file: string, line: string) { return this.request<{ to: string; from: string }>("POST", "/capabilities/skill/move", { from, to, file, line }); }
  async decideLesson(id: string, decision: "accept" | "dismiss", text?: string, layer?: "general" | "private"): Promise<void> {
    await this.request<void>("POST", `/lessons/${encodeURIComponent(id)}`, { decision, text, layer });
  }
  decideAction(id: string, decision: "approve" | "always" | "deny") {
    return this.request<void>("POST", `/actions/${encodeURIComponent(id)}/decide`, { decision });
  }
  async answer(): Promise<void> {
    throw new ApiError("Tasks arrive in a later milestone.", 501);
  }

  onEvent(listener: (ev: ServerEvent) => void) {
    this.listeners.add(listener);
    if (!this.source) {
      // EventSource reconnects by itself; after a reconnect we may have missed
      // events, so ask the app to reload its lists.
      this.source = new EventSource(`${this.base}/api/events`, { withCredentials: true });
      let opened = false;
      this.source.onopen = () => {
        if (opened) this.emit({ type: "resync" });
        opened = true;
      };
      this.source.onmessage = (e) => {
        try {
          this.emit(JSON.parse(e.data) as ServerEvent);
        } catch { /* ignore malformed */ }
      };
      this.source.addEventListener("resync", () => this.emit({ type: "resync" }));
    }
    return () => this.listeners.delete(listener);
  }

  private emit(ev: ServerEvent) {
    this.listeners.forEach((l) => l(ev));
  }
}
