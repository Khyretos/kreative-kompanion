/// pure: true when a computer grant on `target` reaches `folder`.
pub fn covers(target: &str, folder: &str) -> bool {
    if folder.is_empty() {
        return false;
    }
    let target = target.trim_end_matches('/');
    let folder = folder.trim_end_matches('/');
    if target.is_empty() || !target.starts_with('/') {
        return false;
    }
    if folder == "/" || target == folder {
        return true;
    }
    if target == "/" {
        return true;
    }
    if folder.starts_with(&format!("{}/", target)) {
        return true;
    }
    if target.starts_with(&format!("{}/", folder)) {
        return true;
    }
    false
}
