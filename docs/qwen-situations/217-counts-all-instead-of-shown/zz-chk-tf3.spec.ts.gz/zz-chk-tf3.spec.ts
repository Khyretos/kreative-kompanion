// Check for unit tf3 (filterDeps, setDep in web/src/views/deppicker.ts) on a bare page.
import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";

test("filterDeps and setDep toggle the picker", async ({ page }) => {
  const js = readFileSync(process.env.DP_JS ?? "/tmp/dp.js", "utf8");
  await page.setContent("<form><div id=host></div></form>");
  await page.addScriptTag({ content: js });
  const r = await page.evaluate(() => {
    const DP = (window as unknown as { DP: Record<string, (...a: unknown[]) => unknown> }).DP;
    const T = (id: string, title: string) => ({ id, title, projectId: "p", state: "queued" });
    const host = document.getElementById("host")!;
    host.innerHTML = String(DP.depPicker(["a"], [T("a", "Write docs"), T("b", "Ship build"), T("c", "Write tests")]));
    const picker = host.querySelector<HTMLElement>(".dep-picker")!;
    const vis = () => [...picker.querySelectorAll<HTMLElement>(".dep-option")].filter((o) => !o.hidden).map((o) => o.dataset.id).join(",");
    const chips = () => [...picker.querySelectorAll<HTMLElement>(".dep-chip")].filter((o) => !o.hidden).map((o) => o.dataset.id).join(",");
    const sent = () => new FormData(host.closest("form")!).getAll("deps").join(",");
    const none = () => picker.querySelector<HTMLElement>(".dep-none")!.hidden;
    const out: Record<string, string | boolean> = {};
    DP.filterDeps(picker, "WRITE"); out.filterWrite = vis();
    DP.filterDeps(picker, "zzz"); out.filterNone = vis(); out.noneShown = !none();
    DP.filterDeps(picker, ""); out.filterAll = vis(); out.noneHidden = none();
    const search = picker.querySelector<HTMLInputElement>("#dep-search")!;
    search.value = "ship";
    DP.setDep(picker, "b", true);
    out.afterAddChips = chips(); out.afterAddSent = sent(); out.afterAddOptions = vis();
    out.searchCleared = search.value === ""; out.searchFocused = document.activeElement === search;
    DP.setDep(picker, "a", false);
    out.afterRemoveChips = chips(); out.afterRemoveSent = sent(); out.afterRemoveOptions = vis();
    DP.setDep(picker, "nope", true); out.unknownChips = chips();
    return out;
  });
  expect(r.filterWrite, "filterDeps(picker, 'WRITE'): visible options (a is chosen, so only c)").toBe("c");
  expect(r.filterNone, "filterDeps(picker, 'zzz'): no visible options").toBe("");
  expect(r.noneShown, "filterDeps with no match: .dep-none must be shown (hidden = false)").toBe(true);
  expect(r.filterAll, "filterDeps(picker, ''): every not chosen option").toBe("b,c");
  expect(r.noneHidden, "filterDeps with matches: .dep-none must be hidden").toBe(true);
  expect(r.afterAddChips, "setDep(picker, 'b', true): visible chips").toBe("a,b");
  expect(r.afterAddSent, "setDep(picker, 'b', true): the form sends deps").toBe("a,b");
  expect(r.afterAddOptions, "setDep(picker, 'b', true): options left (search cleared, so all not chosen)").toBe("c");
  expect(r.searchCleared, "setDep must clear #dep-search").toBe(true);
  expect(r.searchFocused, "setDep must focus #dep-search").toBe(true);
  expect(r.afterRemoveChips, "setDep(picker, 'a', false): visible chips").toBe("b");
  expect(r.afterRemoveSent, "setDep(picker, 'a', false): the form sends deps").toBe("b");
  expect(r.afterRemoveOptions, "setDep(picker, 'a', false): a is offered again").toBe("a,c");
  expect(r.unknownChips, "setDep with an unknown id changes nothing").toBe("b");
});
