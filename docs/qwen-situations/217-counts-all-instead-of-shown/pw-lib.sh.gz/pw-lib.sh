# sourced by checks: pw <file-for-errors> <playwright args...>
NM=/home/khyretos/Docker/Personal-projects/kreative-kompanion/web/node_modules
[ -e web/node_modules ] || ln -s $NM web/node_modules
pw() {
  ef=$1; shift
  timeout 600 docker run --rm --network host -u $(id -u):$(id -g) -e HOME=/tmp -e CI=1 -e DP_JS -v $PWD:/w -v $NM:$NM:ro -w /w/web mcr.microsoft.com/playwright:v1.63.0-noble npx playwright test "$@" --reporter=line --retries=0 > /tmp/kk-chk-pw.out 2>&1 && return 0
  grep -v WebServer /tmp/kk-chk-pw.out | grep -vE "^\[[0-9]+/[0-9]+\]|^  [0-9]+\) " | grep -E "^\s+(Error|Expected|Received|Locator)|TypeError|timed out" | sort -u | head -20 | sed "s|^ *|error: $ef: |"
  return 1
}
tsc_ok() {
  (cd web && npx tsc --noEmit -p .) > /tmp/kk-chk-tsc.out 2>&1 && return 0
  grep -E "error TS" /tmp/kk-chk-tsc.out | head -15 | sed 's/^/error: /'; return 1
}
