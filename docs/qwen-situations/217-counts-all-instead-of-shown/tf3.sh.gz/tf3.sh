cd ${UNIT_DIR:-/tmp/kk-tf-tf3} || exit 1
. /tmp/kk-chk-tf/pw-lib.sh
f=web/src/views/deppicker.ts
tsc_ok || exit 1
grep -q "export function filterDeps(picker: HTMLElement, query: string): void" $f || { echo "error: $f: add export function filterDeps(picker: HTMLElement, query: string): void"; exit 1; }
grep -q "export function setDep(picker: HTMLElement, id: string, on: boolean): void" $f || { echo "error: $f: add export function setDep(picker: HTMLElement, id: string, on: boolean): void"; exit 1; }
web/node_modules/.bin/esbuild $f --bundle --format=iife --global-name=DP --outfile=web/dp-chk.js --log-level=error || { echo "error: $f: esbuild could not bundle it"; exit 1; }
cp /tmp/kk-chk-tf/zz-chk-tf3.spec.ts web/tests/
DP_JS=/w/web/dp-chk.js pw $f tests/zz-chk-tf3.spec.ts; r=$?
rm -f web/tests/zz-chk-tf3.spec.ts web/dp-chk.js; exit $r
