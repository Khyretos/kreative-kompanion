  async getOverview(projectId: string): Promise<import("./types").ProjectOverview> {
    const p = projects.find((x) => x.id === projectId);
    if (!p) throw new Error("No such project.");
    const text = overviewText[projectId] ?? { about: "", links: [] };
    const m = p.repoMachineId ? machines.find((x) => x.id === p.repoMachineId) : undefined;
    const folder = p.repoFolder ?? null;
    const where = {
      machine: m ? { id: m.id, name: m.name, online: m.online, os: m.os || null } : null,
      folder,
      git: m ? { remote: `https://git.kreative-kompas.com/khyretos/${p.name}`, branch: "main", at: ago(5) } : null,
      gitState: m ? "known" : "none",
    };
    const grants = when(m && folder)
      : (grants[m.id] ?? []).filter((g) => g.target.startsWith("/") && (folder === g.target || folder.startsWith(g.target + "/"))).map((g) => ({ target: g.target, rights: g.rights, expires: g.expires })),
      else [],
    const dev = devSettings[projectId] ?? emptyDev();
    const commands = when(m)
      : (["build", "test", "run", "deploy"] as const).filter((k) => dev[k].trim()).map((k) => ({ kind: k, command: dev[k], last: dev.last[k] ?? null, fromHere: k !== "deploy" })),
      else [],
    const access = { grants, mcp: [{ server: "Blender", tool: "*", expires: hoursFromNow(48) }], knowledge: [], assets: (projectAssets[projectId] ?? []).length, commands };
    const mine = tasks.filter((t) => t.projectId === projectId);
    const progress = {
      done: mine.filter((t) => t.state === "done").length,
      total: mine.length,
      running: mine.filter((t) => t.state === "running").length,
      needsYou: mine.filter((t) => t.state === "needs_input" || t.state === "failed").length,
      inReview: mine.filter((t) => t.state === "in_review").length,
      goals: [],
      next: mine.filter((t) => t.state === "queued").slice(0, 3).map((t) => ({ id: t.id, title: t.title, ready: true })),
      lastMerged: null,
    };
    const activity = [...new Set(mine.flatMap((t) => events.filter((e) => e.taskId === t.id)))]
      .concat(chats.filter((c) => c.projectId === projectId))
      .sort((a, b) => b.at.localeCompare(a.at))
      .slice(0, 10)
      .map((e) => {
        const t = mine.find((x) => x.id === (e.taskId ?? -1));
        if (!t) return null;
        return { what: `${t.title}: ${"text" in e ? e.text : e.kind}`, at: e.at, who: t.model };
      })
      .concat(chats.filter((c) => c.projectId === projectId).map((c) => ({ what: `Chat: ${c.title}`, at: c.updatedAt, who: "" })) as any)
      .sort((a, b) => b.at.localeCompare(a.at))
      .slice(0, 10);
    const ai = mine.length ? [{ model: "Qwen3.5-9B", runs: 4, tokens: 182000, minutes: 12.5 }, { model: "DeepSeek V3", runs: 1, tokens: 24000, minutes: 1.2 }] : [];
    return structuredClone({
      id: p.id,
      name: p.name,
      description: p.description,
      about: text.about,
      type: p.type ?? "chat",
      kind: p.kind ?? "internal",
      source: null,
      links: text.links,
      createdAt: ago(60 * 24 * 30),
      updatedAt: p.updatedAt,
      archivedAt: p.archivedAt ?? null,
      owner: "kees",
      where,
      access,
      progress,
      activity,
      ai,
      automation: { scheduler: { enabled: false, budget: { minutes: null, rounds: null, tokens: null } }, overseer: !!p.overseer },
      errors: {},
    });
  }
  async getDevSettings(projectId: string) {
    const p = projects.find((x) => x.id === projectId);
    if (!p) throw new Error("No such project.");
    return structuredClone({ settings: devSettings[projectId] ?? emptyDev(), presets: DEV_PRESETS, repoMachineId: p.repoMachineId ?? null, repoFolder: p.repoFolder ?? null });
