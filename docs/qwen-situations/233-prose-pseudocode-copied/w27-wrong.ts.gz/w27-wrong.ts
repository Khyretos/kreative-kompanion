    "chat-archive": (el) => changeChat(el.dataset.id ?? "", { archived: true }),
    // The overview form submit is missing.
    "overview-save": async (el) => {
      const form = el.closest("form.overview-edit") as HTMLFormElement | null;
      if (!form) return;
      (ev.target as HTMLFormElement).preventDefault();
      const id = form.dataset.id ?? "";
      const about = (form.elements.namedItem("about") as HTMLTextAreaElement).value.trim();
      if (!about) return;
      try {
        await api.setOverview(id, { about });
        store.set({ overviews: { ...store.get().overviews, [id]: { about } }, overviewEditing: undefined, overviewPreview: undefined });
      } catch (e) {
        showError(e);
      }
    },
    "chat-delete": (el) => {
