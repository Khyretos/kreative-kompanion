/**
 * Composes a task description from its parts.
 */
export interface DescParts {
  goal: string;
  steps: string;
  done: string;
  notes: string;
}

/**
 * Composes a task description from its parts.
 */
export function composeDescription(p: DescParts): string {
  const normalizeLine = (s: string) => s.replace(/\n/g, " ").trim();

  const goalBlock = p.goal ? "**Goal:** " + normalizeLine(p.goal) : "";
  const doneBlock = p.done ? "**Done when:** " + normalizeLine(p.done) : "";

  const stepsLines = p.steps.split("\n").map((line) => {
    const markerRegex = /^\s*(\d+[.)]|[-*])\s+/;
    const cleaned = line.replace(markerRegex, "").trim();
    return cleaned.length > 0 ? cleaned : null;
  }).filter((x): x is string => x !== null);

  let stepsBlock = "";
  if (stepsLines.length > 0) {
    stepsBlock = "**Steps**\n" + stepsLines.map((s, i) => `${i + 1}. ${s}`).join("\n");
  }

  const notesBlock = p.notes.trim() ? p.notes.trim() : "";

  const blocks: string[] = [];
  if (goalBlock) blocks.push(goalBlock);
  if (stepsBlock) blocks.push(stepsBlock);
  if (doneBlock) blocks.push(doneBlock);
  if (notesBlock) blocks.push(notesBlock);

  return blocks.length === 0 ? "" : blocks.join("\n\n");
}

/**
 * Parses a task description into its parts.
 */
export function parseDescription(md: string): DescParts {
  md = md.replace(/\r\n/g, "\n");
  const lines = md.split("\n");
  const result: DescParts = { goal: "", steps: "", done: "", notes: "" };

  let goalLineIdx = -1;
  let doneLineIdx = -1;
  let stepsStartIdx = -1;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.match(/^\*\*Goal:\*\*\s/)) {
      goalLineIdx = i;
    } else if (line.match(/^\*\*Done when:\*\*\s/)) {
      doneLineIdx = i;
    } else if (line === "**Steps**") {
      stepsStartIdx = i;
    }
  }

  if (goalLineIdx >= 0 && goalLineIdx < lines.length) {
    result.goal = lines[goalLineIdx].replace(/^\*\*Goal:\*\*\s*/, "").trim();
  }

  if (doneLineIdx >= 0 && doneLineIdx < lines.length) {
    result.done = lines[doneLineIdx].replace(/^\*\*Done when:\*\*\s*/, "").trim();
  }

  if (stepsStartIdx >= 0 && stepsStartIdx < lines.length) {
    const stepMarkerRegex = /^\s*\d+[.)]\s*/;
    let i = stepsStartIdx + 1;
    while (i < lines.length && lines[i].match(stepMarkerRegex)) {
      const stepText = lines[i].replace(stepMarkerRegex, "").trim();
      if (stepText.length > 0) {
        if (result.steps.length > 0) result.steps += "\n";
        result.steps += stepText;
      }
      i++;
    }
  }

  let noteLines: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const isGoal = line.match(/^\*\*Goal:\*\*\s/);
    const isDone = line.match(/^\*\*Done when:\*\*\s/);
    const isStepsHeader = line === "**Steps**";
    const isStepLine = line.match(/^\s*\d+[.)]\s*/);

    if (!isGoal && !isDone && !isStepsHeader && !isStepLine) {
      noteLines.push(line);
    }
  }

  result.notes = noteLines.join("\n").trim();

  return result;
}
