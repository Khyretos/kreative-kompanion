cd ${UNIT_DIR:-/tmp/kk-tf-tf1} || exit 1
f=web/src/views/taskdesc.ts
. /tmp/kk-chk-tf/pw-lib.sh
[ -s $f ] || { echo "error: $f: file not written"; exit 1; }
tsc_ok || exit 1
web/node_modules/.bin/esbuild $f --format=esm --outfile=/tmp/kk-tf1-$$.mjs --log-level=error || { echo "error: $f: esbuild could not bundle it"; exit 1; }
node /tmp/kk-chk-tf/tf1-test.mjs /tmp/kk-tf1-$$.mjs; r=$?; rm -f /tmp/kk-tf1-$$.mjs; exit $r
