const { composeDescription: c, parseDescription: p } = await import(process.argv[2]);
const f = "web/src/views/taskdesc.ts";
let bad = 0;
const eq = (what, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  if (g !== w) { console.log(`error: ${f}: ${what}: got ${g}, want ${w}`); bad++; }
};
eq("compose all parts", c({ goal: "A build.", steps: "Write docs\n2. Run tests\n- Upload\n\n", done: "It works.", notes: "Use **Tracy**." }),
  "**Goal:** A build.\n\n**Steps**\n1. Write docs\n2. Run tests\n3. Upload\n\n**Done when:** It works.\n\nUse **Tracy**.");
eq("compose skips empty parts", c({ goal: "G", steps: "  ", done: "D", notes: "" }), "**Goal:** G\n\n**Done when:** D");
eq("compose joins a multi-line goal", c({ goal: "one\ntwo ", steps: "", done: "", notes: "" }), "**Goal:** one two");
eq("compose of nothing", c({ goal: "", steps: "", done: "", notes: "" }), "");
eq("parse a composed text", p("**Goal:** A build.\n\n**Steps**\n1. Write docs\n2. Run tests\n\n**Done when:** It works.\n\nUse **Tracy**."),
  { goal: "A build.", steps: "Write docs\nRun tests", done: "It works.", notes: "Use **Tracy**." });
eq("parse a one-line goal", p("**Goal:** Profile shader compile times."), { goal: "Profile shader compile times.", steps: "", done: "", notes: "" });
eq("parse free text into notes", p("Just do the thing.\n\n- a\n- b"), { goal: "", steps: "", done: "", notes: "Just do the thing.\n\n- a\n- b" });
eq("parse the old empty template", p("**Goal:** \n\n**Steps**\n1. \n\n**Done when:** "), { goal: "", steps: "", done: "", notes: "" });
eq("parse empty", p(""), { goal: "", steps: "", done: "", notes: "" });
eq("parse keeps a numbered list outside Steps in notes", p("Do this:\n1. a\n2. b"), { goal: "", steps: "", done: "", notes: "Do this:\n1. a\n2. b" });
eq("compose skips a blank goal", c({ goal: "   ", steps: "", done: "D", notes: "" }), "**Done when:** D");
eq("compose collapses spaces around a newline", c({ goal: "one \n  two", steps: "", done: "", notes: "" }), "**Goal:** one two");
eq("parse a goal line without a space after the label", p("**Goal:**G\n**Done when:**D"), { goal: "G", steps: "", done: "D", notes: "" });
eq("parse keeps a free numbered list in notes", p("1. a\n2. b"), { goal: "", steps: "", done: "", notes: "1. a\n2. b" });
eq("parse takes the first Goal line only", p("**Goal:** A\n**Goal:** B"), { goal: "A", steps: "", done: "", notes: "**Goal:** B" });
const x = { goal: "G", steps: "a\nb", done: "D", notes: "## More\ntext" };
eq("round trip", p(c(x)), x);
process.exit(bad ? 1 : 0);
