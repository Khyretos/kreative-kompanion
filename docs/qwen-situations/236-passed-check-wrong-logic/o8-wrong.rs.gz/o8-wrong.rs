pub async fn refresh_git(s: AppState, user_id: String, project_id: String, machine_id: String, folder: String) {
    s.host.watch(&user_id);
    let job = match crate::access::queue_job(&s.db, &machine_id, &user_id, &json!({ "tool": "shell", "cwd": folder, "command": "git remote get-url origin; git branch --show-current" }), None).await {
        Ok(j) => j,
        Err(_) => return,
    };

    let start = util::now();
    loop {
        tokio::time::sleep(Duration::from_millis(500)).await;
        let row: Option<(String, Option<String>)> = sqlx::query_as("SELECT state, result FROM machine_jobs WHERE id = ?")
            .bind(&job)
            .fetch_optional(&s.db)
            .await.ok().flatten();
        if let Some((state, result)) = row {
            if state == "done" {
                if let Some((remote, branch)) = parse_git(&result.unwrap_or_default()) {
                    let _ = sqlx::query("UPDATE projects SET repo_git = ? WHERE id = ? AND user_id = ?")
                        .bind(json!({ "remote": remote, "branch": branch, "at": util::now() }).to_string())
                        .bind(&project_id)
                        .bind(&user_id)
                        .execute(&s.db)
                        .await;
                }
                return;
            } else if state == "failed" || state == "refused" {
                return;
            }
        }
    }
}

