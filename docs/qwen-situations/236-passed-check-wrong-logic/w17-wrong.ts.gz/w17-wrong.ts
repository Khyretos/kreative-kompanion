function activity(v: OverviewView): SafeHtml {
  if (!v.o) {
    return html`<p class="muted">Loading…</p>`;
  }
  if (v.o.activity === null) {
    const err = v.o.errors.activity ?? "";
    return html`<p class="muted">Could not read this part: ${err}</p>`;
  }
  if (v.o.activity.length === 0) {
    return html`<p class="muted">Nothing yet.</p>`;
  }
  const shown = v.o.activity.slice(0, v.activityAll ? 10 : 5);
  const moreBtn = !v.activityAll && shown.length > 5
    ? html`<button class="btn small" type="button" data-action="overview-activity-more" data-id="${v.project.id}">More</button>`
    : html``;

  return html`
    <ul class="ov-act">
      ${shown.map((a) => html`
        <li>
          <span class="ov-what">${a.what}</span>
          <span class="ov-when muted">${relTime(a.at)}${a.who ? ` · ${a.who}` : ""}</span>
        </li>
      `)}
    </ul>
    ${moreBtn}
  `;
